# Spin-berhadiah
Spin hadiah adalah permainan interaktif di mana pengguna dapat memutar roda secara virtual untuk berkesempatan memenangkan berbagai hadiah menarik. Dengan sekali putaran, pemain bisa mendapatkan hadiah acak sesuai dengan segmen yang ditunjuk roda setelah berhenti.
